/* FIT9132GDDS 2019 TP3 Assignment 2 Q3 ANSWERS
   Student Name:
    Student ID:

   Comments to your marker:
   Table column date type alteration was required to use the given sequence numbers
   ALTER TABLE service_job MODIFY sj_job_no NUMBER(6);
   ALTER TABLE part_charge MODIFY sj_job_no NUMBER(6);

   
*/

/* (i)*/
-- Alter the data type of the service job number to use sequences
   ALTER TABLE service_job MODIFY sj_job_no NUMBER(6);
   ALTER TABLE part_charge MODIFY sj_job_no NUMBER(6);


CREATE OR REPLACE TRIGGER trg_before_service_insert
BEFORE INSERT
  on service
  FOR EACH ROW 
DECLARE
vehicle_owner NUMBER(6);
BEGIN
-- get the actual customer number associated with the vehicle number being inserted
    select cust_no into vehicle_owner from vehicle where veh_vin = :NEW.veh_vin;
    
    IF (vehicle_owner <> :NEW.cust_no) THEN
      RAISE_APPLICATION_ERROR(-20000,'The vehicle number is not belonging to the customer number entered');
    END IF; 
END;
/

/* (ii)*/

CREATE OR REPLACE TRIGGER trg_after_service_update
AFTER UPDATE
  on service
  FOR EACH ROW 
BEGIN
    IF (:OLD.serv_no <> :NEW.serv_no) THEN
        dbms_output.put_line('Service number changed successfully'); 
    END IF; 
END;
/

/* (iii)*/


CREATE OR REPLACE TRIGGER trg_part_charge
AFTER INSERT OR UPDATE OR DELETE
  on part_charge
  FOR EACH ROW 
DECLARE
  available_quantity NUMBER(3);
BEGIN
    IF INSERTING THEN 
      select part_stock into available_quantity from part where part_code = :NEW.part_code;
      
      IF (available_quantity < :NEW.pc_quantity) THEN
            RAISE_APPLICATION_ERROR(-20000,'Requested quantity of part is not available in stock');
      ELSE
          update part set part_stock = part_stock - :NEW.pc_quantity where part_code = :NEW.part_code;
      END IF;
    END IF;
    
    IF UPDATING THEN
        -- returning some extra parts
        IF (:OLD.pc_quantity > :NEW.pc_quantity) THEN
            update part set part_stock = part_stock + (:OLD.pc_quantity - :NEW.pc_quantity) where part_code = :NEW.part_code;
        -- requesting some more parts
        ELSIF (:OLD.pc_quantity < :NEW.pc_quantity) THEN
            -- get the available stock 
            select part_stock into available_quantity from part where part_code = :NEW.part_code;
            -- requested parts count is not in stock
            IF ( (:NEW.pc_quantity - :OLD.pc_quantity) > available_quantity ) THEN
                        RAISE_APPLICATION_ERROR(-20000,'Requested additional quantity of part is not available in stock');
            ELSE
                --requested additional parts are in stock
                update part set part_stock = part_stock - (:NEW.pc_quantity - :OLD.pc_quantity) where part_code = :NEW.part_code;
            END IF;
            
        END IF;
    END IF;
    
    IF DELETING THEN
        update part set part_stock = part_stock + :OLD.pc_quantity where part_code = :OLD.part_code;
    END IF;

END;
/
