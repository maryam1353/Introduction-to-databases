
/* FIT9132GDDS 2019 TP3 Assignment 2 Q2 ANSWERS
   Student Name: Maryam Mahmoodi
    Student ID: 30155843

   Comments to your marker:
   
*/

/* (i)*/
-- Join the three tables vehicle, service and service_job and list the vehicle details and job details of a given service number according to the service job order.
select v.veh_vin, v.veh_rego, v.veh_make, sj.sj_job_no, sj.sj_task_description  from vehicle v, service s, service_job sj where s.serv_no=&service_number and v.veh_vin = s.veh_vin and s.serv_no=sj.serv_no order by sj.sj_job_no asc;

/* (ii)*/

select p.part_code, p.part_description, v.vendor_id, v.vendor_name, p.part_stock, CONCAT('$', to_char((p.part_stock * p.part_unit_cost), 'fm99990.00')) as STOCK_VALUE from part p, vendor v where p.vendor_id=v.vendor_id order by p.part_code asc;
select * from part;

    
/* (iii)*/
--TRUNC(SysDate,'YEAR') returns the first date of the current year
--https://community.oracle.com/thread/73981
--List vehicles manufactured before current year
--select v.veh_vin, v.veh_year,  from vehicle v where v.veh_year < TRUNC(SysDate,'YEAR');

--Find vehicles with make Mazda or Ford
--select * from vehicle v where v.veh_make in ('Mazda', 'Ford');

select c.cust_no, c.cust_name, c.cust_phone,  to_char(v.veh_year, 'YYYY') || ' ' || v.veh_make || ' ' || v.veh_model as VEHICLEDETAILS
from vehicle v, customer c where v.cust_no=c.cust_no and v.veh_year < TRUNC(SysDate,'YEAR') and v.veh_make in ('Mazda', 'Ford');



/* (iv)*/

select c.cust_no, c.cust_name, to_char(s.serv_date, 'DD-MON-YY') as SERV_DATE, v.veh_vin, s.serv_no, s.serv_instructions from service s, customer c, vehicle v where c.cust_no=s.cust_no and s.veh_vin=v.veh_vin and s.serv_instructions like '%General Service%' order by c.cust_no asc, s.serv_date asc, v.veh_vin asc; 

 
/* (v)*/

select * from 
(
select p.part_code, p.part_description, v.vendor_name, ('Used in at least one service') as PARTUSAGE  from part p, vendor v where p.vendor_id=v.vendor_id and p.part_code in (select pc.part_code from part_charge pc) 
UNION
select p.part_code, p.part_description, v.vendor_name, ('Not used in any service') as PARTUSAGE  from part p, vendor v where p.vendor_id=v.vendor_id and p.part_code not in (select pc.part_code from part_charge pc)
) order by part_code;


    
/* (vi)*/

-- Here, it says the current unit cost in part table might not be the same price where the part was sold. In that case, we should look at the total part cost in service table. 
-- However, since once service can be associated with multiple parts, by looking at total cost we cannot get the price each item was sold in past. 

select * from (
select p.part_code, p.part_description, SUM(pc.pc_quantity) as QUANTITY_USED, SUM(p.part_unit_cost * pc.pc_quantity) as TOTAL_CHARGES from part p, part_charge pc where p.part_code=pc.part_code group by p.part_code, p.part_description 
) order by QUANTITY_USED DESC;

    
/* (vii)*/
--Referred http://nimishgarg.blogspot.com/2009/12/get-dates-difference-in-days-hours.html

select c.cust_no, c.cust_name, s.serv_no, to_char(s.serv_req_pickup, 'HH12:MM AM') AS "Required Pickup Time", to_char(s.serv_ready_pickup, 'HH12:MM AM') AS "Ready for Pickup Time", 
(to_number(to_char(trunc(sysdate) + (serv_ready_pickup-serv_req_pickup), 'HH24')) || ' hr ' || to_number(to_char(trunc(sysdate) + (serv_ready_pickup-serv_req_pickup), 'MI')) || ' mins') AS "Late Delivery" from service s, customer c where c.cust_no = s.cust_no and s.serv_ready_pickup > s.serv_req_pickup;

/* (viii)*/
-- total amount spent on parts by each customer
select CUST_NO, CUST_NAME, TOTAL_PART_PAYMENT from 
(
select c.cust_no, c.cust_name, sum(s.serv_parts_cost) AS TOTAL_PART_PAYMENT from customer c, service s where c.cust_no=s.cust_no group by c.cust_no, c.cust_name
) where TOTAL_PART_PAYMENT > (select AVG(SERV_PARTS_COST) from service ) 
order by TOTAL_PART_PAYMENT DESC;





