/* FIT9132GDDS 2019 TP3 Assignment 2 Q1-Part B ANSWERS
   Student Name: Maryam Mahmoodi
    Student ID: 30155843

   Comments to your marker: In the service_job table creation, it has defined sj_job_no column to have NUMBER(2) where it can store only numbers less than 100. However in this question, we need to use sequences to store numbers from 1000 on this column. So we need to alter the column to NUMBER(4) or more.
   
   CREATE TABLE service_job (
    serv_no               NUMBER(6) NOT NULL,
    sj_job_no             NUMBER(2) NOT NULL,
    sj_task_description   VARCHAR2(50) NOT NULL
);
   
*/

/* (i)*/
CREATE SEQUENCE service_seq START WITH 1000 INCREMENT BY 10;

CREATE SEQUENCE service_job_seq START WITH 1000 INCREMENT BY 10 ;

CREATE SEQUENCE part_charge_seq START WITH 1000 INCREMENT BY 10;


--Altering the sj_job_no column of table service_job to use this sequence
ALTER TABLE service_job MODIFY sj_job_no NUMBER(6);


/* (ii)*/

select cust_no from customer where cust_phone = '6715573197';
select * from vehicle where cust_no = (select cust_no from customer where cust_phone = '6715573197') ;


update vehicle set veh_rego = 'GDD132' where veh_vin = (select veh_vin from vehicle where cust_no = (select cust_no from customer where cust_phone = '6715573197'));
commit;


/* (iii)*/

insert into SERVICE ( SERV_NO, SERV_DATE, SERV_DROP_OFF, SERV_REQ_PICKUP, SERV_READY_PICKUP, SERV_KMS, SERV_LABOUR_COST, SERV_PARTS_COST, SERV_INSTRUCTIONS, PAY_MODE_CODE, VEH_VIN, CUST_NO ) 
values ( SERVICE_SEQ.nextval, TO_DATE('2019/06/20', 'yyyy/mm/dd'), TO_DATE('2019/06/20 8:30:00', 'YYYY/MM/DD HH24:MI:SS'), TO_DATE('2019/06/20 12:00:00', 'YYYY/MM/DD HH24:MI:SS'), null, 12000, null, null, 'Check rear seat belts for proper retracting', 'S', (select veh_vin from vehicle where cust_no = 1030), 1030 ); 
commit;

select * from service where cust_no = 1030;
      
/* (iv)*/

--Locate the service number of the customer with number 1030 being served on the given date
--select serv_no from service where cust_no = 1030 and serv_date = TO_DATE('2019/06/20', 'yyyy/mm/dd');


DECLARE
    service_number NUMBER(6) NULL;
BEGIN 

  SELECT serv_no INTO :service_number  FROM service where cust_no = 1030 and serv_date = TO_DATE('2019/06/20', 'yyyy/mm/dd');
  
  insert into SERVICE_JOB (SERV_NO, SJ_JOB_NO, SJ_TASK_DESCRIPTION) values (:service_number, SERVICE_JOB_SEQ.nextval, 'Reare seat belt retracting issue fixed');

  update service set serv_ready_pickup = TO_DATE('2019/06/20 9:10:00', 'YYYY/MM/DD HH24:MI:SS'), serv_labour_cost = 0, serv_parts_cost = 0 where serv_no = :service_number;
  
  commit;
END;
/

/* (v)*/

select * from vendor;
select * from part;

--List the part details of the particular vendor
select * from part where vendor_id = (select vendor_id from vendor where vendor_name = 'Australian Automotive Parts');

--List the part codes of the particular vendor
select part_code from part where vendor_id = (select vendor_id from vendor where vendor_name = 'Australian Automotive Parts');

--Search for used parts in previous services from this vendor
select * from part_charge where part_code in (select part_code from part where vendor_id = (select vendor_id from vendor where vendor_name = 'Australian Automotive Parts'));

--Above query returns an empty data set, which makes sure we have not used parts of this vendor before in any of the services.

--Find the part_code numbers of the parts of this vendor
select part_code from part where vendor_id = (select vendor_id from vendor where vendor_name = 'Australian Automotive Parts');

--delete the parts of this vendor
delete from part where part_code in (select part_code from part where vendor_id = (select vendor_id from vendor where vendor_name = 'Australian Automotive Parts'));
select * from part;
commit;
