/* FIT9132GDDS 2019 TP3 Assignment 2 Q4 ANSWERS
   Student Name: Maryam Mahmoodi
    Student ID: 30155843

   Comments to your marker:
   
*/
/* (i)*/

alter table part add part_reorder_level number(3);
alter table part add part_restock_date date;
update part set part_reorder_level = CEIL(part_stock / 2);
update part set part_restock_date = TO_DATE(trunc(sysdate), 'YYYY/MM/DD HH24:MI:SS');
select * from part;

/* (ii)*/

CREATE TABLE staff (
    staff_id   NUMBER(6) NOT NULL,
    staff_name     VARCHAR2(30) NOT NULL,
    staff_mobile   VARCHAR2(10) NOT NULL,
    role_id        NUMBER(6) NOT NULL
);
ALTER TABLE staff ADD CONSTRAINT staff_pk PRIMARY KEY ( staff_id );
CREATE SEQUENCE staff_seq START WITH 1000 INCREMENT BY 10 NOCACHE NOCYCLE;


CREATE TABLE staff_role (
    role_id NUMBER(6) NOT NULL,
    role_name VARCHAR2(50) NOT NULL
);
ALTER TABLE staff_role ADD CONSTRAINT staff_role_pk PRIMARY KEY ( role_id );
ALTER TABLE staff ADD CONSTRAINT staff_role_fk FOREIGN KEY ( role_id ) REFERENCES staff_role ( role_id );
CREATE SEQUENCE staff_role_seq START WITH 1000 INCREMENT BY 10 NOCACHE NOCYCLE;


INSERT INTO staff_role (role_id, role_name) values (staff_role_seq.nextval, 'Sales');
INSERT INTO staff_role (role_id, role_name) values (staff_role_seq.nextval, 'Reception');
INSERT INTO staff_role (role_id, role_name) values (staff_role_seq.nextval, 'Mechanic');
INSERT INTO staff_role (role_id, role_name) values (staff_role_seq.nextval, 'Spare Parts');
INSERT INTO staff_role (role_id, role_name) values (staff_role_seq.nextval, 'General');
INSERT INTO staff_role (role_id, role_name) values (staff_role_seq.nextval, 'Front Office');
commit;

select * from staff_role;

INSERT INTO staff (staff_id, staff_name, staff_mobile, role_id) VALUES (staff_seq.nextval, 'John Smith', '123456789', (select role_id from staff_role where role_name = 'Reception'));
INSERT INTO staff (staff_id, staff_name, staff_mobile, role_id) VALUES (staff_seq.nextval, 'Steve Taylor', '58447662', (select role_id from staff_role where role_name = 'Mechanic'));

select * from staff;

ALTER TABLE service ADD CONSTRAINT service_staff_fk FOREIGN KEY ( staff_id ) REFERENCES staff ( staff_id );



CREATE OR REPLACE TRIGGER trg_service_insert_update
BEFORE INSERT OR UPDATE
  on service
  FOR EACH ROW 
DECLARE
  reception_role_id NUMBER(6);
  current_member_role_id NUMBER(6);
BEGIN
    IF INSERTING THEN
        --prevent creating services without a staff member id
        IF (:NEW.staff_id IS NULL) THEN
            RAISE_APPLICATION_ERROR(-20000,'Services must be created by a staff member');
        END IF;
    
        -- Get the id of the role with name Reception.
        select role_id into reception_role_id from staff_role where role_name = 'Reception';
        -- Get the current member's role id
        select role_id into current_member_role_id from staff where staff_id = :NEW.staff_id;
        
        IF (reception_role_id <> current_member_role_id) THEN
             RAISE_APPLICATION_ERROR(-20000,'Services can be only added by staff members in Reception');
        END IF;
        
    END IF;
    
    IF UPDATING THEN
        -- if the staff id is being updated, overwrite it to old staff id
        IF (:NEW.staff_id <> :OLD.staff_id) THEN
            :NEW.staff_id := :OLD.staff_id;
            RAISE_APPLICATION_ERROR(-20000,'Staff ID of existing services cannot be changed');
        END IF;
    END IF;
END;
/
